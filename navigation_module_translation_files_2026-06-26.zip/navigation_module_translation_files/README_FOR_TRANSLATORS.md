# Bronch Navigation Trainer Translation Handoff

Created: 2026-06-26

This package contains the source files in `navigation_module` that currently hold learner-visible English text for the bronch navigation trainer. The files are copied with their repo paths preserved so translated versions can be merged back into the app deliberately.

## Files Included

- `web/index.html`
  - Browser page title and document language.
- `web/src/App.tsx`
  - Main trainer UI copy: wizard steps, instructions, buttons, feedback, status labels, target wording, test scoring, and debug labels.
- `web/src/components/BronchoscopeView.tsx`
  - Virtual bronchoscope panel labels, loading/error states, branch-selection accessibility labels, and patient-orientation overlay wording.
- `web/src/components/CtPane.tsx`
  - CT pane titles, airway-aligned view titles, slice-position accessibility labels, and target marker text.
- `web/src/components/AirwayMap.tsx`
  - 3D airway map panel labels and option toggle copy.
- `web/src/caseLoader.ts`
  - User-visible load/error messages if case data or sidecars fail to load.
- `web/src/route.ts`
  - Contains English airway label strings used for routing logic. Do not directly translate these unless the routing logic is updated or separate display labels are added.
- `web/public/cases/default/case.json`
  - Runtime case metadata. The visible strings are currently `noduleTargets[].label` values such as "Beginner nodule" and "Advanced nodule".
- `web/public/cases/default/book_candidates.json`
  - Optional authoring/debug airway label overlay source. Translate only if translated candidate labels are intended to appear in authoring/debug overlays.

## Translation Notes

- Preserve JSON keys, schema names, IDs, file paths, asset IDs, node/edge IDs, numeric arrays, and coordinate data.
- Branch choice labels `A`, `B`, `C`, etc. are used as option identifiers and should usually remain unchanged.
- Patient orientation labels `R`, `L`, `A`, and `P` are radiology/anatomy orientation markers; review with a clinician before changing them.
- In `book_candidates.json`, `candidateLabel` values may also be consumed by `web/src/route.ts` for route behavior. For production localization, prefer adding separate display translations rather than replacing routing labels in place.
- Raw volume files, STL meshes, calibration JSON, `node_modules`, built `dist` files, and documentation were not included because they do not need translation for the runtime learner module.
